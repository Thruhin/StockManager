package com.pconiq.assignment.stock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
