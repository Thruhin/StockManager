package com.pconiq.assignment.stock.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pconiq.assignment.stock.Constants;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.pconiq.assignment.stock.model.restobjects.StockDetails;
import com.pconiq.assignment.stock.model.restobjects.StocksResponse;
import com.pconiq.assignment.stock.repo.entity.Stock;
import com.pconiq.assignment.stock.repo.entity.StockPrice;
import com.pconiq.assignment.stock.repo.repository.StockRepository;
import com.pconiq.assignment.stock.util.StocksUtil;

@Service
public class StockServiceImpl implements StockService{
    
    @Autowired
    private StockRepository stockRepository;

    public StocksResponse geStocks() {
        
        List<Stock> stocks =  stockRepository.findAll();
        List<StockDetails> stockDetails = new ArrayList<>();
        for(Stock stock: stocks) {
            StockDetails stockDetail = new StockDetails();
            stockDetail.setStockId(stock.getStockId());
            stockDetail.setCompanyUrl(stock.getCompanyUrl());
            stockDetail.setCreatedTime(stock.getCreatedTime());
            stockDetail.setCurrencyCode(stock.getCurrencyCode());
            stockDetail.setCurrentPrice(stock.getCurrentPrice());
            stockDetail.setCurrentPrice(stock.getCurrentPrice());
            stockDetail.setDescription(stock.getDescription());
            stockDetail.setName(stock.getName());
            stockDetail.setLastUpdate(stock.getLastUpdated());
            stockDetails.add(stockDetail);
        }
        StocksResponse response = new StocksResponse();
        response.setStocks(stockDetails);
        response.setStatusCode("S-100");
        response.setStatusMessage("Stocks retreived succesfully");
        return response;
    }
    
    
    public Page<Stock> gePagedStocks(Integer top, Integer skip){
        skip = StocksUtil.getSkipOrTopValue(skip, Constants.DEFAULT_SKIP_VALUE);
        top = StocksUtil.getSkipOrTopValue(top, Constants.DEFAULT_TOP_VALUE);
        top = (top > Constants.DEFAULT_TOP_VALUE) ? Constants.DEFAULT_TOP_VALUE : top;
        Page<Stock> temp =  stockRepository.findAll(PageRequest.of((skip / top), top));
        return temp;
    }

    public StockDetails geStockById(Long stockId) {
        
        Optional<Stock> stockOptional= stockRepository.findById(stockId);
        
        Stock stock = stockOptional.get();
        
        StockDetails stockDetail = new StockDetails();
        stockDetail.setStockId(stock.getStockId());
        stockDetail.setCompanyUrl(stock.getCompanyUrl());
        stockDetail.setCreatedTime(stock.getCreatedTime());
        stockDetail.setCurrencyCode(stock.getCurrencyCode());
        stockDetail.setCurrentPrice(stock.getCurrentPrice());
        stockDetail.setCurrentPrice(stock.getCurrentPrice());
        stockDetail.setDescription(stock.getDescription());
        stockDetail.setName(stock.getName());
        stockDetail.setLastUpdate(stock.getLastUpdated());
        stockDetail.setStockPrices(stock.getStockPrices());
        
        return stockDetail;
       
    }

}
