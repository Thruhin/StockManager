package com.pconiq.assignment.stock;

public class Constants {
    
    public static final String POSTGRES_DRIVER = "org.postgresql.Driver";
    
    public static final int POSTGRES_INITIAL_SIZE = 5;
    public static final int POSTGRES_MAX_ACTIVE = 50;
    public static final int POSTGRES_MIN_IDLE = 5;
    public static final int POSTGRES_MAX_IDLE = 10;
    
    public static final String POSTGRES_VALIDATION_QUERY = "SELECT 1";
    
    public static final String TABLE_STOCK = "STOCK";
    public static final String TABLE_STOCK_PRICE_HISTORY = "STOCK_PRICE_HISTORY";
    
    public static final Integer DEFAULT_SKIP_VALUE = 0;
    public static final Integer DEFAULT_TOP_VALUE = 200;
    
}
