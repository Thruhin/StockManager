package com.pconiq.assignment.stock.util;

public class StocksUtil {
    
    public static Integer getSkipOrTopValue(Integer inputValue, Integer defaultValue) {
        return (inputValue == null) ? defaultValue : inputValue;
      }

}
