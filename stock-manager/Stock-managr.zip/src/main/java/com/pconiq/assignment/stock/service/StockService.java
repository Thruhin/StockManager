package com.pconiq.assignment.stock.service;

import org.springframework.data.domain.Page;

import com.pconiq.assignment.stock.model.restobjects.StockDetails;
import com.pconiq.assignment.stock.model.restobjects.StocksResponse;
import com.pconiq.assignment.stock.repo.entity.Stock;

public interface StockService {
    
    public StocksResponse geStocks();
    
    public Page<Stock> gePagedStocks(Integer top, Integer skip);
    
    public StockDetails geStockById(Long id);

}
