package com.pconiq.assignment.stock.repo.entity;

import java.io.Serializable;
import java.security.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Embeddable
@EqualsAndHashCode
@NoArgsConstructor
public class StockPriceId implements Serializable{/**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    @Column(name = "id")
    private long id;
    
    @Column(name = "LAST_UPDATED_TS")
    private Timestamp lastUpdated;
    

}
