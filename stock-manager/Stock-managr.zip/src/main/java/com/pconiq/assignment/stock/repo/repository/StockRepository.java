package com.pconiq.assignment.stock.repo.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pconiq.assignment.stock.repo.entity.Stock;


@Repository
public interface StockRepository extends JpaRepository<Stock, Long>{
    
    @Query(value = "SELECT * FROM STOCK LIMIT :top OFFSET :skip",
        nativeQuery = true)
    public List<Stock> getAllStocks(@Param("top") int top, @Param("skip") int skip);
    
    public Page<Stock> findAll(Pageable pageable);
    
}
