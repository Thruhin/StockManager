package com.pconiq.assignment.stock.model.restobjects;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseResponse implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String statusCode;

    private String statusMessage;

}