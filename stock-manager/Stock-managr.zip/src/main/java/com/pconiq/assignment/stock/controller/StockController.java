package com.pconiq.assignment.stock.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Size;
import javax.websocket.server.PathParam;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pconiq.assignment.stock.model.restobjects.StockDetails;
import com.pconiq.assignment.stock.model.restobjects.StocksResponse;
import com.pconiq.assignment.stock.repo.entity.Stock;
import com.pconiq.assignment.stock.service.StockService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController
public class StockController {
    
    org.slf4j.Logger logger = LoggerFactory.getLogger(StockController.class.getName());
    
    @Autowired
    private StockService stockService;
    
    @Operation(summary = "Get all the available Stocks")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Registry details deleted successfully"),
        @ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found"),
        @ApiResponse(responseCode = "400", description = "Bad request. Invalid request"),
        @ApiResponse(responseCode = "500", description = "Failed to delete registry") })
    @GetMapping(value = "/stocks")
    public StocksResponse getStocks(@RequestParam(value = "skip", required = false) Integer skip,
        @RequestParam(value = "top", required = false) Integer top) {
        
        StocksResponse response = stockService.geStocks();
        logger.error("Nicely done", "2345", "Some message");
        return response;
    }
    
    @Operation(summary = "Get all the available Stocks with Pagination")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Registry details deleted successfully"),
        @ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found"),
        @ApiResponse(responseCode = "400", description = "Bad request. Invalid request"),
        @ApiResponse(responseCode = "500", description = "Failed to delete registry") })
    @GetMapping(value = "/paged/stocks")
    public Page<Stock> getPagedStocks(@RequestParam(value = "skip", required = false) Integer skip,
        @RequestParam(value = "top", required = false) Integer top) {
        Page<Stock> response = stockService.gePagedStocks(top, skip);
        return response;
    }
    
    @Operation(summary = "Get history information of a Stocks")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Registry details deleted successfully"),
        @ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
        @ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found"),
        @ApiResponse(responseCode = "400", description = "Bad request. Invalid request"),
        @ApiResponse(responseCode = "500", description = "Failed to delete registry") })
    @GetMapping(value = "/stocks/{stockId}")
    public StockDetails getStock(@PathVariable Long stockId) {
        
        StockDetails response = stockService.geStockById(stockId);
        logger.error("Nicely done", "2345", "Some message");
        return response;
    }
    
    @PostMapping(value = "/stock")
    public List<StockDetails> createStock(@RequestBody StockDetails stock) {
        return null;
    }
    
    @PatchMapping(value = "/stock")
    public List<StockDetails> updateStock(@RequestBody StockDetails stock) {
        return null;
    }
    
    @DeleteMapping(value = "/stock/{stockId}")
    public List<StockDetails> deleteStock(@PathVariable Integer stock) {
        return null;
    }
    
}
