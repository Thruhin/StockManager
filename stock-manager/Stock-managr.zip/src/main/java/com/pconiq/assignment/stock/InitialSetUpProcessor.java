package com.pconiq.assignment.stock;

import java.sql.Connection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;

import com.pconiq.assignment.stock.model.restobjects.StockDetails;

import liquibase.Contexts;
import liquibase.LabelExpression;
import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.exception.DatabaseException;
import liquibase.exception.LiquibaseException;
import liquibase.resource.ClassLoaderResourceAccessor;

@Configuration
public class InitialSetUpProcessor {
    
    Logger logger = LoggerFactory.getLogger(InitialSetUpProcessor.class.getName());
    
    String liquibaseChangeLogMaster = "/db/master-onboard.xml";
    
    @Autowired
    private LiquibaseConfigService liquibaseConfigService;
    
    @EventListener
    @Async
    public void onApplicationEvent(ContextRefreshedEvent event) throws Exception {
        
        executeInitialSetupScripts();
        initialStockDataInsert();
        
    }

    private void initialStockDataInsert() {
        
        for(int i=0; i< 100; i++) {
            StockDetails stock = new StockDetails();
           // stock.set()
        }
    }

    private void executeInitialSetupScripts() throws Exception {

       // Release Liquibase locks on the schema if any
       // liquibaseConfigService.releaseLock(cacheDataSource.getDefaultCacheDatasource(), schema, schema);
        logger.info("Executing Liquibase scripts for tenant {} in schema {} ...");
        
        //Connection dbConnection = liquibaseConfigService.getGlobalPostgresDataSource().getConnection();
        Connection dbConnection = liquibaseConfigService.createPostgresDataSource().getConnection();
        
        if (dbConnection == null) {
            throw new Exception("runLiquibaseOnTenantDatabase: database connection is null for tenant:" );
        }
        Database database = getDatabase(dbConnection);
        Liquibase liquibase = getLiquibase(database);
        try {
            liquibase.update(new Contexts(), new LabelExpression());
        } catch (LiquibaseException ex) {
            throw ex;
        }
        logger.info("Completed executing Liquibase scripts for tenant {} in schema {} (took {} ms)");
        
    }
    
    
    Liquibase getLiquibase(Database database) {
        try {
            logger.debug("getLiquibase: for tenant [{}] using changelog file [{}]" + liquibaseChangeLogMaster);
            return new Liquibase(liquibaseChangeLogMaster, new ClassLoaderResourceAccessor(), database);
        } catch (Exception ex) {
            logger.debug("createTenantDatabase: could not create Liquibase instance for tenant [{}]");
            return null;
        }
    }
    
    Database getDatabase(Connection dbConnection) throws Exception {
        try {
            return getDatabaseFactory().findCorrectDatabaseImplementation(new JdbcConnection(dbConnection));
        } catch (DatabaseException ex) {
            logger.debug("createTenantDatabase: Could not get database for tenant [{}] with driver [{}], version [{}]");
            return null;
        }
    }
    
    DatabaseFactory getDatabaseFactory() {
        return DatabaseFactory.getInstance();
    }



}
