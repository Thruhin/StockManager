package com.pconiq.assignment.stock.repo.entity;

import java.io.Serializable;
import java.security.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.pconiq.assignment.stock.Constants;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = Constants.TABLE_STOCK_PRICE_HISTORY)
public class StockPrice implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1446445210686902161L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "STOCK_ID")
    private long stockId;
    
    @Column(name = "CURRENT_PRICE")
    private long currentPrice;
    
    @Column(name = "LAST_UPDATED_TS")
    private Timestamp lastUpdated;
    
    @Column(name = "CHANGE_IN_PRICE")
    private long changeInPrice;
    
    @Column(name = "OPERATION")
    private String operation;
    
    /*@ManyToOne
    @JoinColumn(name = "ID", nullable = false, insertable = false, updatable = false)
    private Stock stock;     */
    
    @ManyToOne
    @JoinColumn(name="STOCK_ID", insertable = false, updatable = false)
    public Stock stock;

}
