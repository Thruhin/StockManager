package com.pconiq.assignment.stock;

import java.util.Properties;

import javax.sql.DataSource;

import org.postgresql.ds.PGConnectionPoolDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LiquibaseConfigService {
    
    @Autowired
    private EnvVariables env;
    
    public DataSource dataSource;
    
    public PGConnectionPoolDataSource getGlobalPostgresDataSource() {
          PGConnectionPoolDataSource source = new PGConnectionPoolDataSource();
          source.setDatabaseName("stocks_db");
          source.setServerNames(new String[] {"localhost"});
          source.setPortNumbers(new int[] {Integer.parseInt("5433")});
          source.setUser("postgres");
          source.setPassword("password");
          return source;
      }
    
    public DataSource createPostgresDataSource() {
        
        if(dataSource == null) {
            String url = env.getDataSourceUrl();
            org.apache.tomcat.jdbc.pool.DataSource ds = new org.apache.tomcat.jdbc.pool.DataSource();

            ds.setDriverClassName(Constants.POSTGRES_DRIVER);
            ds.setUrl(url);
            ds.setUsername(env.getDbUserName());
            ds.setPassword(env.getDbPassword());
            ds.setInitialSize(Constants.POSTGRES_INITIAL_SIZE);
            ds.setMaxActive(Constants.POSTGRES_MAX_ACTIVE);
            ds.setMinIdle(Constants.POSTGRES_MIN_IDLE);
            ds.setMaxIdle(Constants.POSTGRES_MAX_IDLE);
            ds.setValidationQuery(Constants.POSTGRES_VALIDATION_QUERY);
            ds.setValidationInterval(1000);
            ds.setTestWhileIdle(true);
            ds.setJmxEnabled(true);
            ds.setTestOnBorrow(true);
            dataSource = ds;
        } 
        return dataSource;
    }

}
